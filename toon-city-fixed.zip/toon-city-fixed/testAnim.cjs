const BABYLON = require('@babylonjs/core');
require('@babylonjs/loaders');
const engine = new BABYLON.NullEngine();
const scene = new BABYLON.Scene(engine);
BABYLON.SceneLoader.ImportMeshAsync("", "https://models.babylonjs.com/", "Xbot.glb", scene).then(res => {
  console.log("XBOT:", res.animationGroups.map(a => a.name));
});

BABYLON.SceneLoader.ImportMeshAsync("", "https://models.babylonjs.com/", "dummy3.babylon", scene).then(res => {
  console.log("DUMMY:", res.animationGroups.map(a => a.name));
});
