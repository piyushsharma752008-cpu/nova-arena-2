import React from 'react';

export function CodeBlock({ code, language, title }: { code: string; language: string; title?: string }) {
  return (
    <div className="my-6 rounded-lg overflow-hidden border border-slate-800 bg-slate-950 shadow-lg">
      {title && (
        <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
          <span className="text-xs font-mono text-slate-400">{title}</span>
          <span className="text-xs font-mono text-emerald-500 uppercase">{language}</span>
        </div>
      )}
      <div className="p-4 overflow-x-auto">
        <pre className="text-sm font-mono leading-relaxed text-slate-300">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
}
