import * as BABYLON from '@babylonjs/core';
import { state } from './state.js';
import { mats } from './materials.js';

// Pivot nodes exposed for animation in main loop
export let larmP, rarmP, llegP, rlegP;
export let sprintParticles;

// Walk phase — private; no need to export
let walkCycle = 0;

// ── helpers ──────────────────────────────────────────────────────────────────

function mesh(type, name, opts, parent, pos, mat, scene) {
  const m = type === 'box'
    ? BABYLON.MeshBuilder.CreateBox(name, opts, scene)
    : type === 'sphere'
      ? BABYLON.MeshBuilder.CreateSphere(name, opts, scene)
      : BABYLON.MeshBuilder.CreateCapsule(name, opts, scene);
  m.parent   = parent;
  if (pos) m.position.set(...pos);
  if (mat) m.material = mat;
  return m;
}

// ── public API ────────────────────────────────────────────────────────────────

export function initPlayer() {
  const scene = state.scene;

  // Root nodes
  state.playerNode = new BABYLON.TransformNode('playerNode', scene);
  state.playerNode.rotationQuaternion = BABYLON.Quaternion.Identity();
  const root = new BABYLON.TransformNode('charPivot', scene);
  root.parent = state.playerNode;

  // Materials
  const matShirt = mats.pbr('shirt', [0.08, 0.08, 0.09], 0.0, 0.80);
  const matBag   = mats.pbr('bag',   [0.62, 0.42, 0.22], 0.0, 0.78);
  const matEyeW  = mats.pbr('eyeW',  [1, 1, 1],          0.0, 0.60);
  const matEyeB  = mats.pbr('eyeB',  [0.02, 0.02, 0.03], 0.0, 0.40);

  // Torso + accessories
  const torso = mesh('box', 'torso', { width:0.55, height:0.9, depth:0.35 }, root, [0,1.3,0], matShirt, scene);
  mesh('box', 'jacket', { width:0.65, height:0.92, depth:0.42 }, torso, null, mats.matPlayer, scene);
  mesh('box', 'bag',    { width:0.5,  height:0.58, depth:0.24 }, torso, [0, 0.04, -0.3], matBag, scene);

  // Head
  const head = mesh('sphere', 'head', { diameter:0.7, segments:14 }, torso, [0,0.65,0], mats.matSkin, scene);
  head.scaling.set(1.0, 1.1, 1.0);
  mesh('sphere', 'hood', { diameter:0.75, segments:10 }, torso, [0,0.5,-0.15], mats.matPlayer, scene).scaling.set(1.2, 0.5, 0.8);

  // Hair
  const hair = mesh('sphere', 'hair',  { diameter:0.75, segments:14 }, head, [0,0.05,-0.05], mats.matHair, scene);
  mesh('box', 'hairT', { width:0.6, height:0.3, depth:0.5 }, head, [0,0.35,-0.1], mats.matHair, scene);

  // Eyes
  const mkEye = (name, side) => {
    const eye = mesh('sphere', name+'eye',  { diameter:0.12 }, head, [side*0.15, 0.05, 0.32], matEyeW, scene);
    mesh('sphere', name+'pup', { diameter:0.06 }, eye, [0, 0, 0.06], matEyeB, scene);
  };
  mkEye('l', -1); mkEye('r', 1);

  // Arms
  const mkArm = (name, side) => {
    const pivot = new BABYLON.TransformNode(name+'P', scene);
    pivot.parent = torso;
    pivot.position.set(side * 0.4, 0.35, 0);
    mesh('capsule', name,         { radius:0.08, height:0.9 }, pivot, [0,-0.45,0], mats.matSkin, scene);
    mesh('box',     name+'sleeve',{ width:0.26, height:0.45, depth:0.26 }, pivot, [0,-0.2,0], mats.matPlayer, scene);
    return pivot;
  };
  larmP = mkArm('larm', -1);
  rarmP = mkArm('rarm',  1);

  // Legs
  const mkLeg = (name, side) => {
    const pivot = new BABYLON.TransformNode(name+'P', scene);
    pivot.parent = torso;
    pivot.position.set(side * 0.16, -0.45, 0);
    mesh('capsule', name,       { radius:0.1,  height:0.9  }, pivot, [0,-0.45,0], mats.matSkin, scene);
    mesh('box', name+'short',   { width:0.28, height:0.45, depth:0.30 }, pivot, [0,-0.2,0], mats.matPants, scene);
    mesh('box', name+'shoe',    { width:0.2,  height:0.15, depth:0.34 }, pivot, [0,-0.85,0.05], mats.matShoe, scene);
    return pivot;
  };
  llegP = mkLeg('lleg', -1);
  rlegP = mkLeg('rleg',  1);

  // Register all meshes for shadow casting
  root.getChildMeshes(false).forEach(m => {
    state.shadowGen.addShadowCaster(m, false);
    m.receiveShadows = true;
  });

  // Physics capsule collider
  if (state.physicsOk) {
    state.collider = BABYLON.MeshBuilder.CreateCapsule('collider', { radius: 0.4, height: 2.2 }, scene);
    state.collider.position.y = 8;
    state.collider.isVisible  = false;
    state.colliderAgg = new BABYLON.PhysicsAggregate(
      state.collider, BABYLON.PhysicsShapeType.CAPSULE,
      { mass: 1, friction: 0, restitution: 0 }, scene
    );
  } else {
    state.playerNode.position.y = 1;
  }

  // Sprint dust particles
  sprintParticles = new BABYLON.ParticleSystem('dust', 100, scene);
  sprintParticles.particleTexture = new BABYLON.Texture('https://assets.babylonjs.com/environments/flare.png', scene);
  sprintParticles.emitter    = state.playerNode;
  sprintParticles.minEmitBox = new BABYLON.Vector3(-0.3, 0.05, -0.3);
  sprintParticles.maxEmitBox = new BABYLON.Vector3( 0.3, 0.40,  0.3);
  sprintParticles.color1     = new BABYLON.Color4(0.85, 0.72, 0.55, 0.4);
  sprintParticles.color2     = new BABYLON.Color4(0.90, 0.80, 0.65, 0.2);
  sprintParticles.colorDead  = new BABYLON.Color4(0, 0, 0, 0);
  sprintParticles.minSize    = 0.3;  sprintParticles.maxSize    = 0.8;
  sprintParticles.minLifeTime= 0.08; sprintParticles.maxLifeTime= 0.25;
  sprintParticles.emitRate   = 0;
  sprintParticles.blendMode  = BABYLON.ParticleSystem.BLENDMODE_ADD;
  sprintParticles.direction1 = new BABYLON.Vector3(-0.1, -0.05, -0.1);
  sprintParticles.direction2 = new BABYLON.Vector3( 0.1,  0.05,  0.1);
  sprintParticles.minEmitPower = 0.3; sprintParticles.maxEmitPower = 1.0;
  sprintParticles.updateSpeed  = 0.02;
  sprintParticles.start();
}

export function updatePlayerAnim(dt, speed) {
  if (speed > 0.5) {
    walkCycle += dt * speed * 0.75;
    const s  = Math.sin(walkCycle);
    const sw = s * 0.75;
    larmP.rotation.x =  sw;
    rarmP.rotation.x = -sw;
    llegP.rotation.x = -sw;
    rlegP.rotation.x =  sw;
    // Subtle vertical bob
    larmP.parent.parent.position.y = Math.abs(Math.sin(walkCycle * 2)) * 0.08;
  } else {
    larmP.rotation.x = rarmP.rotation.x = llegP.rotation.x = rlegP.rotation.x = 0;
    larmP.parent.parent.position.y = 0;
  }
}
