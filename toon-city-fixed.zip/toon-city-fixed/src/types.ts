import React from 'react';

export type DeliverableSection = 
  | 'overview'
  | 'architecture'
  | 'structure'
  | 'database'
  | 'network'
  | 'controller'
  | 'vehicle'
  | 'streaming'
  | 'npc'
  | 'missions'
  | 'performance'
  | 'roadmap'
  | 'prototype';

export interface DocContent {
  id: DeliverableSection;
  title: string;
  description: string;
  content: React.ReactNode;
}
