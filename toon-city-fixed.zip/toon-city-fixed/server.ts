import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import http from "http";
import { Server } from "socket.io";

async function startServer() {
  const app = express();
  const PORT = 3000;
  const server = http.createServer(app);
  const io = new Server(server, {
    cors: {
      origin: "*",
    },
  });

  // Basic API for health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", game: "Nova City Arena" });
  });

  // State
  const players = new Map();

  io.on("connection", (socket) => {
    console.log("Client connected:", socket.id);
    
    // Default guest profile
    players.set(socket.id, {
      id: socket.id,
      name: "Guest_" + Math.floor(Math.random() * 1000),
      x: 0,
      y: 10,
      z: 0,
      rotationY: 0,
      health: 100,
      team: Math.random() > 0.5 ? "alpha" : "omega",
      state: "idle",
      isDead: false
    });

    socket.on("join", (data) => {
      const p = players.get(socket.id);
      if (data && data.name) p.name = data.name;
      if (data && data.team) p.team = data.team;
      
      // Tell this player about everyone else
      const others = [];
      players.forEach((val, key) => {
        if (key !== socket.id) others.push(val);
      });
      socket.emit("initPlayers", others);

      // Tell everyone else about this player
      socket.broadcast.emit("playerJoined", p);
    });

    socket.on("updatePosition", (data) => {
      const p = players.get(socket.id);
      if (p) {
        if (data.x !== undefined) p.x = data.x;
        if (data.y !== undefined) p.y = data.y;
        if (data.z !== undefined) p.z = data.z;
        if (data.rotationY !== undefined) p.rotationY = data.rotationY;
        if (data.state !== undefined) p.state = data.state;
        
        socket.broadcast.emit("playerMoved", {
          id: socket.id,
          x: p.x,
          y: p.y,
          z: p.z,
          rotationY: p.rotationY,
          state: p.state
        });
      }
    });

    socket.on("shoot", (data) => {
      socket.broadcast.emit("playerShot", {
        id: socket.id,
        origin: data.origin,
        dir: data.dir
      });
    });

    socket.on("hit", (data) => {
      const targetId = data.targetId;
      const damage = data.damage || 25;
      const target = players.get(targetId);
      if (target && !target.isDead) {
        target.health -= damage;
        io.emit("playerHit", {
          id: targetId,
          health: target.health,
          attackerId: socket.id
        });

        if (target.health <= 0) {
          target.health = 0;
          target.isDead = true;
          io.emit("playerDied", {
            id: targetId,
            attackerId: socket.id
          });
          
          setTimeout(() => {
            const p = players.get(targetId);
            if (p) {
              p.health = 100;
              p.isDead = false;
              // Reset pos (will be handled by client choosing spawn)
              io.emit("playerRespawn", { id: targetId });
            }
          }, 3000);
        }
      }
    });

    socket.on("disconnect", () => {
      console.log("Client disconnected:", socket.id);
      players.delete(socket.id);
      socket.broadcast.emit("playerLeft", socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
